#include <iostream>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <queue>
#include <fstream>


/* ősosztály várakozó szálakhoz. */
struct Synchronizable {
    private:
        std::mutex mtx;
        std::condition_variable cv;
        bool run = false;

    protected:
        /* csak ősosztálynak használható */
        Synchronizable() = default;
        ~Synchronizable() = default;

    public:
        /* a szál elaltatja magát */
        void sleep() {
            std::unique_lock<std::mutex> lock{mtx};
            cv.wait(lock, [=] { return run; });
            run = false;
        }
        /* kívülről ezt kell meghívni, hogy a szál felébredjen */
        void wakeup() {
            std::unique_lock<std::mutex> lock{mtx};
            run = true;
            cv.notify_one();
        }
};


/* modul: ilyenek futását fogja vezérelni a kernel. */
class Module: public Synchronizable {
    public:
        virtual void do_stuff() = 0;
        virtual ~Module() {}

    protected:
        /* szimulációban: adott ideig várakozik a modul */
        void wait(int interval);
};


/* szimulációs kernel, ez vezérli a modulokat. amíg egy modul dolgozik,
 * a kernel alszik, úgyhogy ez is Synchronizable */
class Kernel: public Synchronizable {
    private:
        int sim_time = 0;

        struct Event {
            int sim_time;
            Module* module;
            bool operator< (Event const& e) const {
                return this->sim_time > e.sim_time;     /* idő szerint növekvő sorrendhez */
            }
        };
        std::priority_queue<Event> events;
        
        /* singleton */
        Kernel() = default;
        Kernel(Kernel const&) = delete;

    public:
        /* singleton */
        static Kernel& instance() {
            static Kernel instance;
            return instance;
        }

        /* szimuláció indítása valamekkora időtartamig */
        void simulate(int interval);

        /* modul száljának indítása */
        void register_module(Module& m);

        /* esemény beszúrása az ütemezőnek: ennyi időpont múlva fel kell ébreszteni a modult */
        void schedule_event(int interval, Module& p);

        int get_sim_time() const {
            return sim_time;
        }
};


void Module::wait(int interval) {
    /* ennyi idő múlva újra keltsen föl a kernel. */
    Kernel::instance().schedule_event(interval, *this);
    /* kernelt fölkelteni, mi meg alszunk. */
    Kernel::instance().wakeup();
    this->sleep();
}


/* szimuláció indítása valamekkora időtartamig */
void Kernel::simulate(int interval) {
    int stop = sim_time + interval;
    while (sim_time < stop && !events.empty()) {
        /* következő esemény a sorból */
        Event the_event = events.top();
        events.pop();
        
        /* az idő most: ami ebbe az eseménybe van írva (közte nem történt semmi) */
        sim_time = the_event.sim_time;

        /* modul felébresztése, és várakozás, amíg végzett */
        the_event.module->wakeup();
        this->sleep();
    }
}


/* szál indítása az adott modulhoz */
void Kernel::register_module(Module& module) {
    /* alvó állapotban kezd a szál */
    std::thread t{[&] {
        module.sleep();
        module.do_stuff();
    }};
    t.detach();

    /* majd ha indul a szimuláció, egyből lefuthat a függvénye */
    schedule_event(0, module);
}


/* esemény beszúrása az ütemezőnek: ennyi időpont múlva fel kell ébreszteni a modult */
void Kernel::schedule_event(int interval, Module& module) {
    events.push(Event{sim_time+interval, &module});
}


class VCDLogger {
    private:
        std::ofstream os;

    public:
        /* logger létrehozása, output a megadott fájlban */
        VCDLogger() : os("clocks.vcd") {}

        /* új vezeték */
        void new_wire(char wire) {
            os << "$var wire 1 " << wire << " " << wire << " $end\n";
        }

        /* érték megváltozásának logolása */
        void value_change(char wire, int value) {
            os << '#' << Kernel::instance().get_sim_time() << std::endl << value << wire << std::endl;
        }
};

VCDLogger logger;


/* példa modul: órajelgenerátor */
class Clock: public Module {
    private:
        char wire;
        int interval;

    public:
        Clock(char wire, int interval): wire(wire), interval(interval) {
            logger.new_wire(wire);
            Kernel::instance().register_module(*this);
        }

        /* itt a lényeg: órajelgenerátor. ez egy szálban fut,
         * a végtelen ciklusból soha nem jön ki. */
        void do_stuff() override {
            while (true) {
                logger.value_change(wire, 0);
                wait(interval);
                logger.value_change(wire, 1);
                wait(interval);
            }
        }
};

int main() {
    Clock a{'a', 5};
    Clock b{'b', 12};

    Kernel::instance().simulate(200);
}
