#include <cstddef>         // size_t
#include <iostream>        // std::cout
#include <utility>         // std::pair
#include <functional>      // std::function
#include <string>          // std::string
#include <memory>          // std::shared_ptr
#include <vector>          // std::vector

// BASIC, GLOBAL TYPES
using match_range = std::pair<std::string::const_iterator, std::string::const_iterator>;
using semantic_action = std::function <void(std::string const &)>;

// TREE NODE
struct node {
	std::string name;
	match_range matching_range;
	std::vector<std::shared_ptr<node>> children;

	node(std::string const &name, match_range matching_range) : name(name), matching_range(matching_range) {}
};

void print_tree(std::shared_ptr<node> root, size_t level = 0) {
	if (root) {
		for (size_t i = 0; i < level; ++i) std::cout << "\t";
		std::cout << root->name << "  (" << std::string(root->matching_range.first, root->matching_range.second) << ")" << std::endl;
		for (auto &child: root->children) print_tree(child, level + 1);
	}
}

// BASE CLASS FOR THE RULES
class base_rule {
	private:
		virtual bool test(match_range &context , match_range &matching_range, std::shared_ptr<node> &root) = 0;

	protected:
		semantic_action the_semantic_action;
		std::string name;

	public:
		base_rule(std::string const &name) : name(name) {}

		virtual ~base_rule() {}

		bool match(match_range &context , match_range &matching_range, std::shared_ptr<node> &root);

		base_rule &operator[] (semantic_action const &an_action);

		virtual std::shared_ptr<base_rule> clone() const = 0;
};

bool base_rule::match(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, result;

	if (test(local , result, root)) {
		context = local;
		matching_range = result;

		if (the_semantic_action) {
			the_semantic_action(std::string(result.first, result.second));
		}
		
		return true;
	}
	
	return false;
}

base_rule &base_rule::operator[] (semantic_action const &an_action) {
	the_semantic_action = an_action;
	return *this;
}

// CHARACTER RULE
class character : public base_rule {
	private:
		std::string values;
	
	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		character(std::string const &values) : base_rule("character"), values(values) {}
		virtual std::shared_ptr <base_rule > clone() const override;
};

bool character::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	if (context.first == context.second) return false;

	for (auto c : values) {
		if (*context.first == c) {
			matching_range = std::make_pair(context.first , context.first + 1);
			++context.first;

			root = std::make_shared<node>(name, matching_range);

			return true;
		}
	}

	return false;
}

std::shared_ptr<base_rule> character::clone() const {
	return std::shared_ptr<base_rule>(new character(*this));
}

// REPETITION RULE
class repetition : public base_rule {
	private:
		std::shared_ptr<base_rule> the_rule;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		repetition(std::shared_ptr<base_rule> a_rule) : base_rule("repetition"), the_rule(a_rule) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool repetition::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, the_match;
	std::shared_ptr<node> repeated;

	if (the_rule->match(local, the_match, repeated)) {
		root = std::make_shared<node>(name, the_match);
		root->children.push_back(repeated);

		while (the_rule->match(local, the_match, repeated)) {
			root->children.push_back(repeated);
		}
	
		matching_range.first = context.first;
		matching_range.second = the_match.second;
		context = local;

		root->matching_range =  matching_range;
		
		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> repetition::clone() const {
	return std::shared_ptr<base_rule>(new repetition(*this));
}

repetition operator +(base_rule const &a_rule) {
	return repetition(a_rule.clone());
}

// CONCATENATION RULE
class concatenation : public base_rule {
	private:
		std::shared_ptr<base_rule> lhs;
		std::shared_ptr<base_rule> rhs;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		concatenation(std::shared_ptr<base_rule> lhs, std::shared_ptr<base_rule> rhs) : base_rule("concatenation"), lhs(lhs), rhs(rhs) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool concatenation::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, lhs_match, rhs_match;
	std::shared_ptr<node> lhs_tree, rhs_tree;

	if (lhs->match(local, lhs_match, lhs_tree) && rhs->match(local, rhs_match, rhs_tree)) {
		matching_range.first = context.first;
		matching_range.second = rhs_match.second;
		context = local;

		root = std::make_shared<node>(name, matching_range);
		root->children.push_back(lhs_tree);
		root->children.push_back(rhs_tree);
		
		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> concatenation::clone() const {
	return std::shared_ptr<base_rule>(new concatenation(*this));
}

concatenation operator <<(base_rule const &lhs_rule, base_rule const &rhs_rule) {
	return concatenation(lhs_rule.clone(), rhs_rule.clone());
}

// ALTERNATION RULE
class alternation : public base_rule {
	private:
		std::shared_ptr<base_rule> lhs;
		std::shared_ptr<base_rule> rhs;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		alternation(std::shared_ptr<base_rule> lhs, std::shared_ptr<base_rule> rhs) : base_rule("alternation"), lhs(lhs), rhs(rhs) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool alternation::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, lhs_match, rhs_match;
	std::shared_ptr<node> lhs_tree, rhs_tree;

	if (lhs->match(local, lhs_match, lhs_tree)) {
		matching_range.first = context.first;
		matching_range.second = lhs_match.second;
		context = local;

		root = std::make_shared<node>(name, matching_range);
		root->children.push_back(lhs_tree);
		
		return true;
	}

	if (rhs->match(local, rhs_match, rhs_tree)) {
		matching_range.first = context.first;
		matching_range.second = rhs_match.second;
		context = local;

		root = std::make_shared<node>(name, matching_range);
		root->children.push_back(rhs_tree);
		
		return true;
	}

	
	return false;
}

std::shared_ptr<base_rule> alternation::clone() const {
	return std::shared_ptr<base_rule>(new alternation(*this));
}

alternation operator |(base_rule const &lhs_rule, base_rule const &rhs_rule) {
	return alternation(lhs_rule.clone(), rhs_rule.clone());
}

// THE RULE
class rule : public base_rule {
	private:
		std::shared_ptr<std::shared_ptr<base_rule>> the_rule;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		rule(std::string const &name, std::shared_ptr<base_rule> a_rule = nullptr) : base_rule(name), the_rule(new std::shared_ptr<base_rule >(a_rule)) {}

		void set_rule(std::shared_ptr <base_rule > a_rule) {
			*the_rule = a_rule;
		}

		rule &operator <<=(base_rule const &a_rule) {
			set_rule(a_rule.clone());
			return *this;
		}
		
		std::shared_ptr<base_rule> clone() const override;
};

bool rule::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, the_match;
	std::shared_ptr<node> rule_tree;

	if (*the_rule == nullptr) throw "Inner rule not set in a rule";

	if ((*the_rule)->match(local, the_match, rule_tree)) {
		matching_range.first = context.first;
		matching_range.second = the_match.second;
		context = local;

		root = std::make_shared<node>(name, matching_range);
		root->children.push_back(rule_tree);
		
		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> rule::clone() const {
	return std::shared_ptr<base_rule>(new rule(*this));
}

// TESTS
bool test_hexa() {
	std::string test = "0x12fa";
	match_range context = {test.begin(), test.end()}, result;
	rule hexa_num("hexa_num"), hexa_prefix("hexa_prefix"), hexa_digit("hexa_digit");
	std::shared_ptr<node> root;
	
	hexa_num <<= hexa_prefix << +hexa_digit;
	hexa_prefix <<= character("0") << character("x");
	hexa_digit <<= character("0123456789abcdef");

	if (hexa_num.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		return match == test;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

bool test_list_of_numbers() {
	std::string test = "0x12fa,0345,012,0xc001";
	match_range context = {test.begin(), test.end()}, result;
	rule list_of_numbers("list_of_numbers"), number("number");
	rule oct_num("oct_num"), oct_prefix("oct_prefix"), oct_digit("oct_digit");
	rule hexa_num("hexa_num"), hexa_prefix("hexa_prefix"), hexa_digit("hexa_digit");
	std::shared_ptr<node> root;
	
	list_of_numbers <<= number << +(character(",") << number);
	number <<= oct_num | hexa_num;

	oct_num <<= oct_prefix << +oct_digit;
	oct_prefix <<= character("0");
	oct_digit <<= character("01234567");

	hexa_num <<= hexa_prefix << +hexa_digit;
	hexa_prefix <<= character("0") << character("x");
	hexa_digit <<= character("0123456789abcdef");

	if (list_of_numbers.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		return match == test;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

int main() {
	std::vector<std::function<bool()>> tests = {
		test_hexa, test_list_of_numbers
	};
	size_t passed = 0;

	for (auto &test: tests) {
		std::cout << "\n[TEST " << (passed + 1) << "]" << std::endl;

		if (test()) {
			++passed;
			std::cout << "\n[PASSED]" << std::endl;
		}
		else std::cout << "\n[FAILED]" << std::endl;
	}


	std::cout << "\n[SUMMARY: " << passed << "/" << tests.size() << " PASSED]" << std::endl;
}

