#include <cstddef>         // size_t
#include <iostream>        // std::cout
#include <utility>         // std::pair
#include <functional>      // std::function
#include <string>          // std::string
#include <memory>          // std::shared_ptr
#include <vector>          // std::vector
#include <iterator>        // std::distance, std::begin, std::end
#include <sstream>         // std::stringstream

// BASIC, GLOBAL TYPES
using match_range = std::pair<std::string::const_iterator, std::string::const_iterator>;

// TREE NODE
struct node {
	std::string name;
	std::vector<std::shared_ptr<node>> children;

	using node_iterator = std::vector<std::shared_ptr<node>>::const_iterator;

	node(std::string const &name, match_range matching_range = match_range()) : name(name), matching_range(matching_range) {}

	void set_match_range(match_range range) {
		matching_range = range;
	}

	match_range get_match_range() {
		size_t size = children.size();
		if (size == 0) return matching_range;
		else return match_range(children[0]->matching_range.first, children[size - 1]->matching_range.second);
	}

	node_iterator cbegin() const {
		return children.cbegin();
	}

	node_iterator cend() const {
		return children.cend();
	}
	
	private:
		match_range matching_range;
};

void print_tree(std::shared_ptr<node> root, size_t level = 0) {
	if (root) {
		for (size_t i = 0; i < level; ++i) std::cout << "\t";
		match_range range = root->get_match_range();
		std::cout << root->name << "  (" << std::string(range.first, range.second) << ")" << std::endl;
		for (auto &child: root->children) print_tree(child, level + 1);
	}
}

// BASE CLASS FOR THE RULES
class base_rule {
	private:
		virtual bool test(match_range &context , match_range &matching_range, std::shared_ptr<node> &root) = 0;

	public:
		virtual ~base_rule() {}

		bool match(match_range &context , match_range &matching_range, std::shared_ptr<node> &root);

		virtual std::shared_ptr<base_rule> clone() const = 0;
};

bool base_rule::match(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, result;

	if (test(local, result, root)) {
		context = local;
		matching_range = result;
		
		return true;
	}
	
	return false;
}

// CHARACTER RULE
class character : public base_rule {
	private:
		std::string values;
	
	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		character(std::string const &values) : values(values) {}
		virtual std::shared_ptr <base_rule > clone() const override;
};

bool character::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	if (context.first == context.second) return false;

	for (auto c : values) {
		if (*context.first == c) {
			matching_range = std::make_pair(context.first , context.first + 1);
			++context.first;

			return true;
		}
	}

	return false;
}

std::shared_ptr<base_rule> character::clone() const {
	return std::shared_ptr<base_rule>(new character(*this));
}

// REPETITION RULE
class repetition : public base_rule {
	private:
		std::shared_ptr<base_rule> the_rule;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		repetition(std::shared_ptr<base_rule> a_rule) : the_rule(a_rule) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool repetition::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, the_match;

	if (the_rule->match(local, the_match, root)) {

		while (the_rule->match(local, the_match, root)) {
		}
	
		matching_range.first = context.first;
		matching_range.second = the_match.second;
		context = local;

		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> repetition::clone() const {
	return std::shared_ptr<base_rule>(new repetition(*this));
}

repetition operator +(base_rule const &a_rule) {
	return repetition(a_rule.clone());
}

// CONCATENATION RULE
class concatenation : public base_rule {
	private:
		std::shared_ptr<base_rule> lhs;
		std::shared_ptr<base_rule> rhs;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		concatenation(std::shared_ptr<base_rule> lhs, std::shared_ptr<base_rule> rhs) : lhs(lhs), rhs(rhs) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool concatenation::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, lhs_match, rhs_match;

	if (lhs->match(local, lhs_match, root) && rhs->match(local, rhs_match, root)) {
		matching_range.first = context.first;
		matching_range.second = rhs_match.second;
		context = local;

		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> concatenation::clone() const {
	return std::shared_ptr<base_rule>(new concatenation(*this));
}

concatenation operator <<(base_rule const &lhs_rule, base_rule const &rhs_rule) {
	return concatenation(lhs_rule.clone(), rhs_rule.clone());
}

// ALTERNATION RULE
class alternation : public base_rule {
	private:
		std::shared_ptr<base_rule> lhs;
		std::shared_ptr<base_rule> rhs;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		alternation(std::shared_ptr<base_rule> lhs, std::shared_ptr<base_rule> rhs) : lhs(lhs), rhs(rhs) {}
		virtual std::shared_ptr<base_rule> clone() const override;
};

bool alternation::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, lhs_match, rhs_match;

	if (lhs->match(local, lhs_match, root)) {
		matching_range.first = context.first;
		matching_range.second = lhs_match.second;
		context = local;

		return true;
	}

	if (rhs->match(local, rhs_match, root)) {
		matching_range.first = context.first;
		matching_range.second = rhs_match.second;
		context = local;

		return true;
	}

	
	return false;
}

std::shared_ptr<base_rule> alternation::clone() const {
	return std::shared_ptr<base_rule>(new alternation(*this));
}

alternation operator |(base_rule const &lhs_rule, base_rule const &rhs_rule) {
	return alternation(lhs_rule.clone(), rhs_rule.clone());
}

// THE RULE
class rule : public base_rule {
	private:
		std::string name;
		std::shared_ptr<std::shared_ptr<base_rule>> the_rule;

	private:
		virtual bool test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) override;

	public:
		rule(std::string const &name, std::shared_ptr<base_rule> a_rule = nullptr) : name(name), the_rule(new std::shared_ptr<base_rule >(a_rule)) {}

		void set_rule(std::shared_ptr <base_rule > a_rule) {
			*the_rule = a_rule;
		}

		rule &operator <<=(base_rule const &a_rule) {
			set_rule(a_rule.clone());
			return *this;
		}
		
		std::shared_ptr<base_rule> clone() const override;
};

bool rule::test(match_range &context, match_range &matching_range, std::shared_ptr<node> &root) {
	match_range local = context, the_match;
	std::shared_ptr<node> rule_node = std::make_shared<node>(name);

	if (*the_rule == nullptr) throw "Inner rule not set in a rule";

	if ((*the_rule)->match(local, the_match, rule_node)) {
		matching_range.first = context.first;
		matching_range.second = the_match.second;
		context = local;

		rule_node->set_match_range(matching_range);
		root->children.push_back(rule_node);
		
		return true;
	}
	
	return false;
}

std::shared_ptr<base_rule> rule::clone() const {
	return std::shared_ptr<base_rule>(new rule(*this));
}

using generator_range = std::pair<node::node_iterator, node::node_iterator>;

// BASE_GENERATOR
class base_generator {
	public:
		virtual bool generate(generator_range &context) = 0;
		virtual std::shared_ptr<base_generator> clone() const = 0;
		virtual ~base_generator() {}
};

class print_value : public base_generator {
	private:
		std::string name;
		std::ostream *stream;

	public:
		print_value(std::string const &name, std::ostream &stream = std::cout) : name(name), stream(&stream) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;

};


bool print_value::generate(generator_range &context) {
	if (context.first == context.second) return false;

	std::shared_ptr<node> current_node = *context.first;

	if (current_node->name != name) return false;

	match_range range = current_node->get_match_range();
	(*stream) << std::string(range.first, range.second);

	++context.first;
	return true;
}

std::shared_ptr<base_generator> print_value::clone() const {
	return std::make_shared<print_value>(*this);
}

// SKIP (GENERATOR)
class skip : public base_generator {
	private:
		std::string name;

	public:
		skip(std::string const &name) : name(name) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool skip::generate(generator_range &context) {
	if (context.first == context.second) return false;

	std::shared_ptr<node> current_node = *context.first;
	if (current_node->name != name) return false;

	++context.first;
	return true;
}

std::shared_ptr<base_generator> skip::clone() const {
	return std::make_shared<skip>(*this);
}

// GENERATOR_CONCATENATION
class generator_concatenation : public base_generator {
	private:
		std::shared_ptr<base_generator> lhs;
		std::shared_ptr<base_generator> rhs;

	public:
		generator_concatenation(std::shared_ptr<base_generator> lhs, std::shared_ptr<base_generator> rhs) : lhs(lhs), rhs(rhs) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool generator_concatenation::generate(generator_range &context) {
	generator_range local = context;

	if (lhs->generate(local) && rhs->generate(local)) {
		context = local;

		return true;
	}

	return false;
}

std::shared_ptr<base_generator> generator_concatenation::clone() const {
	return std::make_shared<generator_concatenation>(*this);
}

generator_concatenation operator <<(base_generator const &lhs, base_generator const &rhs) {
	return generator_concatenation(lhs.clone(), rhs.clone());
}

// GENERATOR
class generator : public base_generator {
	private:
		std::string name;
		std::shared_ptr<std::shared_ptr<base_generator>> the_generator;

	public:
		generator(std::string const &name, std::shared_ptr<base_generator> a_generator = nullptr) : name(name), the_generator(new std::shared_ptr<base_generator>(a_generator)) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;

		generator &operator <<=(base_generator const &a_generator) {
			*the_generator = a_generator.clone();
			return *this;
		}
};

std::shared_ptr<base_generator> generator::clone() const {
	return std::make_shared<generator>(*this);
}

bool generator::generate(generator_range &context) {
	if (context.first == context.second) return false;

	std::shared_ptr<node> current_node = *context.first;
	if (current_node->name != name) return false;

	generator_range children(current_node->cbegin(), current_node->cend());

	if ((*the_generator)->generate(children)) {
		++context.first;
		return true;
	}

	return false;
}

// GENERATOR_REPETITION
class generator_repetition : public base_generator {
	private:
		std::shared_ptr<base_generator> repeated_generator;

	public:
		generator_repetition(std::shared_ptr<base_generator> rhs) : repeated_generator(rhs) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool generator_repetition::generate(generator_range &context) {
	generator_range local = context;

	if (repeated_generator->generate(local)) {
		while (repeated_generator->generate(local));

		context = local;

		return true;
	}

	return false;
}

std::shared_ptr<base_generator> generator_repetition::clone() const {
	return std::make_shared<generator_repetition>(*this);
}

generator_repetition operator +(base_generator const &a_generator) {
	return generator_repetition(a_generator.clone());
}

// GENERATOR_REPETITION_OR_EPSILON
class generator_repetition_or_epsilon : public base_generator {
	private:
		std::shared_ptr<base_generator> repeated_generator;

	public:
		generator_repetition_or_epsilon(std::shared_ptr<base_generator> rhs) : repeated_generator(rhs) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool generator_repetition_or_epsilon::generate(generator_range &context) {
	generator_range local = context;
	bool there_was_a_match = false;

	while (repeated_generator->generate(local)) {
		there_was_a_match = true;
	}

	if (there_was_a_match) {
		context = local;
	}

	return true;
}

std::shared_ptr<base_generator> generator_repetition_or_epsilon::clone() const {
	return std::make_shared<generator_repetition_or_epsilon>(*this);
}

generator_repetition_or_epsilon operator *(base_generator const &a_generator) {
	return generator_repetition_or_epsilon(a_generator.clone());
}

// GENERATOR_ALTERNATION
class generator_alternation : public base_generator {
	private:
		std::shared_ptr<base_generator> lhs;
		std::shared_ptr<base_generator> rhs;

	public:
		generator_alternation(std::shared_ptr<base_generator> lhs, std::shared_ptr<base_generator> rhs) : lhs(lhs), rhs(rhs) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool generator_alternation::generate(generator_range &context) {
	generator_range local = context;

	if (lhs->generate(local)) {
		context = local;
		return true;
	}

	local = context;
	if (rhs->generate(local)) {
		context = local;
		return true;
	}

	return false;
}

std::shared_ptr<base_generator> generator_alternation::clone() const {
	return std::make_shared<generator_alternation>(*this);
}

generator_alternation operator |(base_generator const &lhs, base_generator const &rhs) {
	return generator_alternation(lhs.clone(), rhs.clone());
}

// PRINT_TEXT
class print_text : public base_generator {
	private:
		std::string text;
		std::ostream *stream;

	public:
		print_text(std::string const &text, std::ostream &stream = std::cout) : text(text), stream(&stream) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool print_text::generate(generator_range &context) {
	(*stream) << text;
	return true;
}

std::shared_ptr<base_generator> print_text::clone() const {
	return std::make_shared<print_text>(*this);
}

// IF_NEXT_NODE
class if_next_node : public base_generator {
	private:
		std::string name;
		std::vector<std::shared_ptr<base_generator>> the_generators;

	public:
		template <typename ...generators>
		if_next_node(std::string const &name, generators const & ...generator_arguments) : name(name) {
			std::shared_ptr<base_generator> generator_array[] = { generator_arguments.clone() ... };
			the_generators.insert(the_generators.begin(), std::begin(generator_array), std::end(generator_array));
		}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool if_next_node::generate(generator_range &context) {
	if (context.first == context.second) return false;

	std::shared_ptr<node> current_node = *context.first;
	if (current_node->name != name) return false;

	bool result = true;
	for (auto a_generator: the_generators) {
		result = result && a_generator->generate(context);
	}

	return result;
}

std::shared_ptr<base_generator> if_next_node::clone() const {
	return std::make_shared<if_next_node>(*this);
}

class perform : public base_generator {
	private:
		std::string name;
		std::function<bool(generator_range &)> action;

	public:
		perform(std::string const &name, std::function<bool(generator_range&)> action) : name(name), action(action) {}
		virtual bool generate(generator_range &context) override;
		virtual std::shared_ptr<base_generator> clone() const override;
};

bool perform::generate(generator_range &context) {
	if (context.first == context.second) return false;

	std::shared_ptr<node> current_node = *context.first;
	if (current_node->name != name) return false;

	return action(context);
}

std::shared_ptr<base_generator> perform::clone() const {
	return std::make_shared<perform>(*this);
}

// TESTS
bool test_hexa() {
	// TEST INPUT
	std::string test = "0x12fa";

	// PARSER GRAMMAR PREREQUISITES
	match_range context = {test.begin(), test.end()}, result;
	rule hexa_num("hexa_num"), hexa_prefix("hexa_prefix"), hexa_digit("hexa_digit");
	std::shared_ptr<node> root = std::make_shared<node>("root");

	// GENERATOR GRAMMAR PREREQUISITES
	generator ghexa_num("hexa_num");
	
	// PARSER GRAMMAR
	hexa_num <<= hexa_prefix << +hexa_digit;
	hexa_prefix <<= character("0") << character("x");
	hexa_digit <<= character("0123456789abcdef");

	// GENERATOR GRAMMAR
	ghexa_num <<= print_value("hexa_prefix") << +print_value("hexa_digit");

	if (hexa_num.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		generator_range the_generator_range(root->cbegin(), root->cend());
		bool generation_done = ghexa_num.generate(the_generator_range);

		return match == test && generation_done;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

bool test_list_of_numbers() {
	// TEST INPUT
	std::string test = "0x12fa,0345,012,0xc001";

	// PARSER GRAMMAR PREREQUISITES
	match_range context = {test.begin(), test.end()}, result;
	rule list_of_numbers("list_of_numbers"), number("number");
	rule oct_num("oct_num"), oct_prefix("oct_prefix"), oct_digit("oct_digit");
	rule hexa_num("hexa_num"), hexa_prefix("hexa_prefix"), hexa_digit("hexa_digit");
	std::shared_ptr<node> root = std::make_shared<node>("root");

	// GENERATOR GRAMMAR PREREQUISITES
	generator glist_of_numbers("list_of_numbers"), gfirst_number("number");
	generator gother_numbers("number");
	
	// PARSER GRAMMAR
	list_of_numbers <<= number << +(character(",") << number);
	number <<= oct_num | hexa_num;

	oct_num <<= oct_prefix << +oct_digit;
	oct_prefix <<= character("0");
	oct_digit <<= character("01234567");

	hexa_num <<= hexa_prefix << +hexa_digit;
	hexa_prefix <<= character("0") << character("x");
	hexa_digit <<= character("0123456789abcdef");

	// GENERATOR GRAMMAR
	glist_of_numbers <<= gfirst_number << *gother_numbers;
	gfirst_number <<= print_value("hexa_num") | print_value("oct_num");
	gother_numbers <<= 
		(
			if_next_node("hexa_num", print_text(", ")) << print_value("hexa_num")
		)
		| 
		(
			// Testing that any number of arguments can be added to if_next_node:
			if_next_node("oct_num", print_text(","), print_text(" ")) << print_value("oct_num")
		);

	if (list_of_numbers.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		generator_range the_generator_range(root->cbegin(), root->cend());
		bool generation_done = glist_of_numbers.generate(the_generator_range);

		return match == test && generation_done;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

bool test_list_of_numbers_with_lambda() {
	// TEST INPUT
	std::string test = "0x12fa,0345,012,0xc001";

	// PARSER GRAMMAR PREREQUISITES
	match_range context = {test.begin(), test.end()}, result;
	rule list_of_numbers("list_of_numbers"), number("number");
	rule oct_num("oct_num"), oct_prefix("oct_prefix"), oct_digit("oct_digit");
	rule hexa_num("hexa_num"), hexa_prefix("hexa_prefix"), hexa_digit("hexa_digit");
	std::shared_ptr<node> root = std::make_shared<node>("root");

	// GENERATOR GRAMMAR PREREQUISITES
	generator glist_of_numbers("list_of_numbers"), gnumber("number");
	std::vector<int> the_numbers;
	int a_number;
	std::stringstream ss;

	// PARSER GRAMMAR
	list_of_numbers <<= number << +(character(",") << number);
	number <<= oct_num | hexa_num;

	oct_num <<= oct_prefix << +oct_digit;
	oct_prefix <<= character("0");
	oct_digit <<= character("01234567");

	hexa_num <<= hexa_prefix << +hexa_digit;
	hexa_prefix <<= character("0") << character("x");
	hexa_digit <<= character("0123456789abcdef");

	// GENERATOR GRAMMAR
	glist_of_numbers <<= +gnumber;
	gnumber <<=
		perform(
			"hexa_num",
			[&the_numbers, &a_number, &ss](generator_range &context) -> bool {
				match_range match = (**context.first).get_match_range();
				ss.clear();
				ss << std::hex << std::string(match.first, match.second);
				ss >> a_number;
				the_numbers.push_back(a_number);

				++context.first;
				return true;
			}
		)
		|
		perform(
			"oct_num",
			[&the_numbers, &a_number, &ss](generator_range &context) -> bool {
				match_range match = (**context.first).get_match_range();
				ss.clear();
				ss << std::oct << std::string(match.first, match.second);
				ss >> a_number;
				the_numbers.push_back(a_number);

				++context.first;
				return true;
			}
		);

	if (list_of_numbers.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		generator_range the_generator_range(root->cbegin(), root->cend());
		bool generation_done = glist_of_numbers.generate(the_generator_range);

		if (generation_done) {
			for (auto &i: the_numbers) std::cout << i << std::endl;
		}

		return match == test && generation_done;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

bool test_time_generation() {
	// TEST INPUT
	std::string test = "22:34:06";

	// PARSER GRAMMAR PREREQUISITES
	match_range context = {test.begin(), test.end()}, result;
	rule time("time"), hours("hours"), minutes("minutes"), seconds("seconds"); 
	rule two_digits("two_digits"), separator("separator"); 
	std::shared_ptr<node> root = std::make_shared<node>("root");

	// GENERATOR GRAMMAR PREREQUISITES
	generator gtime("time"), ghours("hours"), gminutes("minutes"), gseconds("seconds");

	// PARSER GRAMMAR
	time <<= hours << separator << minutes << separator << seconds;

	hours      <<= two_digits;
	minutes    <<= two_digits;
	seconds    <<= two_digits;

	two_digits <<= character("0123456789") << character("0123456789");
	separator  <<= character(":");

	// GENERATOR GRAMMAR
	gtime <<= ghours << skip("separator") << gminutes << skip("separator") << gseconds;

	ghours <<= print_value("two_digits") << print_text(" hours ");
	gminutes <<= print_value("two_digits") << print_text(" minutes ");
	gseconds <<= print_value("two_digits") << print_text(" seconds.\n");

	if (time.match(context, result, root)) {
		std::string match = std::string(result.first, result.second);
		std::cout << "Matched: " << match << std::endl;

		print_tree(root);

		generator_range the_generator_range(root->cbegin(), root->cend());
		bool generation_done = gtime.generate(the_generator_range);

		if (generation_done) {
			std::cout << "Generation done" << std::endl;
		}

		return match == test && generation_done;
	}
	else {
		std::cout << "Didn't match" << std::endl;
		return false;
	}
}

int main() {
	std::vector<std::function<bool()>> tests = {
		test_hexa, test_list_of_numbers, test_list_of_numbers_with_lambda,
		test_time_generation
	};
	size_t passed = 0;

	for (auto &test: tests) {
		std::cout << "\n[TEST " << (passed + 1) << "]" << std::endl;

		if (test()) {
			++passed;
			std::cout << "\n[PASSED]" << std::endl;
		}
		else std::cout << "\n[FAILED]" << std::endl;
	}


	std::cout << "\n[SUMMARY: " << passed << "/" << tests.size() << " PASSED]" << std::endl;
}


